<?php
    header("Location: consultar.php?pag=0");
?>